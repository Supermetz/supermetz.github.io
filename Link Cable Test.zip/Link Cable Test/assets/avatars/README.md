Place 16x16 .png files in this folder to use them as avatars in your dialogues

Docs: https://www.gbstudio.dev/docs/assets/ui-elements#avatars
