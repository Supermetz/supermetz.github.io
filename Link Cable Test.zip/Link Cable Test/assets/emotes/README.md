Place 16x16 .png files in this folder to use them as emotes in your game

Docs: https://www.gbstudio.dev/docs/assets/ui-elements#emotes
